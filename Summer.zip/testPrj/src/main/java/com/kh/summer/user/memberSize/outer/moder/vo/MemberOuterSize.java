package com.kh.summer.user.memberSize.outer.moder.vo;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class MemberOuterSize {
	private String userId;
	private int total;
	private int shoulder;
	private int chest;
	private int sleeve;
	private int height;
	private int weight;
}
