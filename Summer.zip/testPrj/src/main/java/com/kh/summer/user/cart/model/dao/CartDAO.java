package com.kh.summer.user.cart.model.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


public interface CartDAO {
	
	List<HashMap<String, String>> selectCartList(int cPage, int numPerPage, String userId);
	
	int deleteCart(int cartNo);

	int selectCartTotalContents(String userId);

	int insertSmallCart(Map<String, String> smallSize);

	int insertMiddleCart(Map<String, String> middleSize);

	int insertLargeCart(Map<String, String> largeSize);

	
}
