package com.kh.summer.user.notice.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.kh.summer.common.util.Utils;
import com.kh.summer.user.board.model.vo.Board;
import com.kh.summer.user.notice.model.service.NoticeService;

@Controller
public class NoticeController {

	@Autowired
	NoticeService noticeService;
	
	@RequestMapping("/community/selectNoticeList.do")
	public String selectNoticeList(@RequestParam( value="cPage", required=false, defaultValue="1")int cPage, Model model) {
		
		int numPerPage = 10; // 한 페이지 당 게시글 and 페이지 수
		
		// 1. 현재 페이지 게시글 구하기
		List<Map<String, String>> noticeList = noticeService.selectNoticeList(cPage, numPerPage);
		
		// 2. 전체 게시글 수 (페이지 처리를 위함)
		int totalContents = noticeService.selectNoticeTotalContents();
		System.out.println(totalContents);
		
		// 3. 페이지 계산된 HTML 구하기
		String pageBar = Utils.getPageBar(totalContents, cPage, numPerPage, "noticeList.do");
	
		System.out.println("noticeList :" + noticeList);
		
		model.addAttribute("noticeList", noticeList);
		model.addAttribute("totalContents", totalContents);
		model.addAttribute("numPerPage", numPerPage);
		model.addAttribute("pageBar", pageBar);
		
		return "user/community/noticeList";
	}
	
	
	@RequestMapping("/community/selectNoticeDetail.do")
	public String noticeView(@RequestParam int no, Model model) {
		
		Map<String, String> notice = noticeService.selectOneNotice(no);
		List<Map<String, String>> attachmentList = noticeService.selectAttachmentList(no);
		List<Map<String, String>> commentList = noticeService.selectBoardCommentList(no);
		
		model.addAttribute("notice", notice)
		.addAttribute("attachmentList", attachmentList)
		.addAttribute("commentList", commentList);
		
		return "user/community/noticeDetail";
	}
	
	@RequestMapping("/community/insertNoticeComment.do")
	public String insertComment(@RequestParam String userId, @RequestParam int bNo, @RequestParam String cContents, Model model) {
		
		Map<String, String> comment = new HashMap<String, String>();
		
		comment.put("USERID", userId);
		comment.put("BNO", String.valueOf(bNo));
		comment.put("CCONTENTS", cContents);
		
		int result = noticeService.insertComment(comment);
		
		// 5. 처리 결과에 따른 view 처리
		String loc = "/community/selectNoticeDetail.do?no="+bNo;
		String msg ="";
		
		if( result > 0 ) {
			msg = "댓글 등록 성공";
		} else {
			msg = "댓글 등록 실패!";
		}
		
		model.addAttribute("loc", loc).addAttribute("msg", msg);
		
		return "common/msg";
	}
	
	@RequestMapping("/community/deleteNoticeComment.do")
	public String deleteComment(@RequestParam int bNo, @RequestParam int bcNo, Model model) {
		
		int result = noticeService.deleteComment(bcNo);
		
		// 5. 처리 결과에 따른 view 처리
		String loc = "/community/selectNoticeDetail.do?no="+bNo;
		String msg ="";
		
		if( result > 0 ) {
			msg = "댓글 삭제 성공";
		} else {
			msg = "댓글 삭제 실패!";
		}
		
		model.addAttribute("loc", loc).addAttribute("msg", msg);
		
		return "common/msg";
	}
	
}
