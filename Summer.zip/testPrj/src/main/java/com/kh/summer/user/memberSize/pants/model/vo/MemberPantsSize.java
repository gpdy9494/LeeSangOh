package com.kh.summer.user.memberSize.pants.model.vo;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class MemberPantsSize {
	private String userId;
	private int total;
	private int waist;
	private int thigh;
	private int rise;
	private int hem;
	private int height;
	private int weight;
}
