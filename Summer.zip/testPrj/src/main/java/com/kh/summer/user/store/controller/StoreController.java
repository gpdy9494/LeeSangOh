package com.kh.summer.user.store.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.kh.summer.common.member.model.service.MemberService;
import com.kh.summer.common.member.model.vo.Member;
import com.kh.summer.common.util.Utils;
import com.kh.summer.user.cart.model.service.CartService;
import com.kh.summer.user.orderinfo.model.service.OrderInfoService;
import com.kh.summer.user.orderinfo.model.vo.OrderInfo;
import com.kh.summer.user.store.model.service.StoreService;
import com.kh.summer.user.store.model.vo.Store;

@SessionAttributes(value = { "member" }) // 모델에 member를 담을시 세션에 자동으로 등록
@Controller
public class StoreController {
	
	@Autowired
	StoreService storeService;
	
	@Autowired
	MemberService memberService;
	
	@Autowired
	OrderInfoService orderinfoService;
	
	@Autowired
	CartService cartService;
	
	@RequestMapping("/store/selectStoreMain.do")
	public String selectStoreMain(Model model) {
		List<Map<String, String>> list = storeService.selectStoreMainList();
		
		System.out.println("list : " + list);
		
		model.addAttribute("list", list);
		
		return "user/store/storeMain";
	}
	
	@RequestMapping("/store/selectStoreOuter.do")
	public String selectStoreOuter(
			@RequestParam( value="cPage", required=false, defaultValue="1") int cPage, 
			@RequestParam(required=false) String sortVal, Model model) {
		
		int numPerPage = 8; // 한 페이지 당 게시글 and 페이지 수 
		
		// 1. 현재 페이지 게시글 구하기
		String sort = sortVal;
		
		List<Map<String, String>> list = storeService.selectStoreOuterList(cPage, numPerPage, sort);
		List<Map<String, String>> bestItems = storeService.selectStoreOuterBestItems();
		
		System.out.println("list : " + list);
		
		// 2. 전체 게시글 수 (페이지 처리를 위함)
		int totalContents = storeService.selectStoreOuterTotalContents();
		
		System.out.println("totalContents : " + totalContents);
		
		// 3. 페이지 계산된 HTML 구하기
		String pageBar = Utils.getPageBar(totalContents, cPage, numPerPage, "selectStoreOuter.do");
		
		model.addAttribute("list", list)
        .addAttribute("totalContents", totalContents)
        .addAttribute("numPerPage", numPerPage)
		.addAttribute("pageBar", pageBar)
		.addAttribute("bestItems", bestItems);
		
		
		return "user/store/outerStore";	
	}
	@RequestMapping("/store/selectStoreTop.do")
	public String selectStoreTop(
			@RequestParam( value="cPage", required=false, defaultValue="1") int cPage, 
			@RequestParam(required=false) String sortVal, Model model) {
		
		int numPerPage = 8; // 한 페이지 당 게시글 and 페이지 수 
		
		// 1. 현재 페이지 게시글 구하기
		String sort = sortVal;
		
		List<Map<String, String>> list = storeService.selectStoreTopList(cPage, numPerPage, sort);
		List<Map<String, String>> bestItems = storeService.selectStoreTopBestItems();
		
		System.out.println("list : " + list);
		 
		// 2. 전체 게시글 수 (페이지 처리를 위함)
		int totalContents = storeService.selectStoreTopTotalContents();
		
		System.out.println("totalContents : " + totalContents);
		
		// 3. 페이지 계산된 HTML 구하기
		String pageBar = Utils.getPageBar(totalContents, cPage, numPerPage, "selectStoreTop.do");
		
		model.addAttribute("list", list)
        .addAttribute("totalContents", totalContents)
        .addAttribute("numPerPage", numPerPage)
		.addAttribute("pageBar", pageBar)
		.addAttribute("bestItems", bestItems);
		
		
		return "user/store/topStore";	
	}
	@RequestMapping("/store/selectStorePants.do")
	public String selectStorePants(
			@RequestParam( value="cPage", required=false, defaultValue="1") int cPage, 
			@RequestParam(required=false) String sortVal, Model model) {
		
		int numPerPage = 8; // 한 페이지 당 게시글 and 페이지 수 
		
		// 1. 현재 페이지 게시글 구하기
		String sort = sortVal;
		
		List<Map<String, String>> list = storeService.selectStorePantsList(cPage, numPerPage, sort);
		List<Map<String, String>> bestItems = storeService.selectStorePantsBestItems();
		
		System.out.println("list : " + list);
		
		// 2. 전체 게시글 수 (페이지 처리를 위함)
		int totalContents = storeService.selectStorePantsTotalContents();
		
		System.out.println("totalContents : " + totalContents);
		
		// 3. 페이지 계산된 HTML 구하기
		String pageBar = Utils.getPageBar(totalContents, cPage, numPerPage, "selectStorePants.do");
		
		model.addAttribute("list", list)
        .addAttribute("totalContents", totalContents)
        .addAttribute("numPerPage", numPerPage)
		.addAttribute("pageBar", pageBar)
		.addAttribute("bestItems", bestItems);		
		
		return "user/store/pantsStore";	
	}	

	@RequestMapping("/store/storeDetail.do")
	public String storeDetail(@RequestParam int no, Model model, Member member) {
		
		String Id = member.getUserId();

		Map<String, String> store = storeService.selectOneStore(no);
		List<Map<String, String>> attachmentList = storeService.selectAttachmentList(no);
		List<Map<String, String>> commentList = storeService.selectStoreCommentList(no);
		System.out.println("store : " + store);
		
		String pType = String.valueOf(store.get("PTYPE"));
		System.out.println("pType : " + pType);
		
		if(pType.equals("1")||pType.equals("2")) { 
			List<Map<String, Object>> size = storeService.selectTopSize(no);
			Map<String, Object> mySize = storeService.selectMyTopSize(Id);
			model.addAttribute("size", size)
			     .addAttribute("mySize", mySize);
			System.out.println("size : " + size);
		} else if(pType.equals("3")){
			List<Map<String, Object>> size = storeService.selectPantsSize(no);
			Map<String, Object> mySize = storeService.selectMyPantsSize(Id);
			model.addAttribute("size", size)
			 	 .addAttribute("mySize", mySize);
			System.out.println("size : " + size);
		}else {
			System.out.println("pType 오류");
		}
		
		Map<String, String> like = new HashMap<String, String>();
		String userId = Id;
		like.put("no", String.valueOf(no));
		like.put("userId", userId);
		
		String likeList = "Y";
		List listisLike = storeService.isLike(like);
		int isLike = (int) listisLike.get(0);
		if(isLike == 0) {
			likeList = "N";
		}
		model.addAttribute("store", store)
			 .addAttribute("member", member)
			 .addAttribute("attachmentList", attachmentList)
			 .addAttribute("commentList", commentList)
			 .addAttribute("pType", pType)
			 .addAttribute("likeList", likeList);
		
		return "user/store/storeDetail";	
	}

	@RequestMapping("/store/updateLike.do")
	@ResponseBody
	public Map<String, Object> updateLike(@RequestParam int no,
								Model model, @RequestParam String userId) {
		boolean check = false;
		Map<String, String> like = new HashMap<String, String>();
		
		like.put("no", String.valueOf(no));
		like.put("userId", userId);
		
		String likeList = "Y";
		List listisLike = storeService.isLike(like);
		int isLike = (int) listisLike.get(0);
		
		if(isLike==0) {
			likeList = "N";
			int a=storeService.updateLike(like);
			check = (a == 0 ? false : true);
		}
		
		Map<String, Object> checkList = new HashMap<String, Object>();
		checkList.put("check", check);
		checkList.put("likeList", likeList);
		return checkList;
	}
	
	@RequestMapping("/store/selectBuyStore.do")
	public String selectBuyStore(@RequestParam int no, Model model,
								 @RequestParam(required=false) int sAmount,
								 @RequestParam(required=false) int mAmount,
								 @RequestParam(required=false) int lAmount,
								 @RequestParam(required=false) String pCode) {
		Map<String, String> store = storeService.selectOneStore(no);
		List<Map<String, String>> attachmentList = storeService.selectAttachmentList(no);
		
		System.out.printf("selectBuyStore.do의 pCode : " + pCode);
		
		model.addAttribute("store", store)
			 .addAttribute("attachmentList", attachmentList)
			 .addAttribute("sAmount", sAmount)
			 .addAttribute("mAmount", mAmount)
			 .addAttribute("lAmount", lAmount)
			 .addAttribute("pCode", pCode);
		
		return "user/store/selectBuyStore";	
	}

	@RequestMapping("/store/successBuyStore.do")
	public String successBuyStore(OrderInfo orderInfo, Model model,
								@RequestParam String pCode) {
		
		String strProductCode = pCode.substring(pCode.lastIndexOf(",")+1);
	
		int pSold = storeService.updateProductSold(strProductCode);
		
		if( pSold > 0 ) {
			System.out.println("판매 수 증가 성공"); 
		} else {
			System.out.println("판매 수 증가 실패");
		}
		
		int result = orderinfoService.insertOrderInfo(orderInfo);
			
		if( result > 0 ) {
			System.out.println("주문내역 추가 성공"); 
		} else {
			System.out.println("주문내역 추가 실패");
		}
		
		return "user/store/successBuyStore";
	}
	
	@RequestMapping("/store/insertCart.do")
	public String selectBuyStore(Model model, HttpServletRequest request,
				@RequestParam(required=false) String pCode, 
				@RequestParam(required=false) int sAmount,
				@RequestParam(required=false) int mAmount,
				@RequestParam(required=false) int lAmount) {
		
		HttpSession session = request.getSession();
		
		Member member = (Member)session.getAttribute("member");
		
		String userId = member.getUserId();
		
		// Small 사이즈 장바구니 추가
		if(sAmount != 0) {
			
			Map<String, String> smallSize = new HashMap<String, String>();
			
			smallSize.put("userId", userId);
			smallSize.put("pCode", pCode);
			smallSize.put("sAmount", String.valueOf(sAmount));
			
			int SmallResult = cartService.insertSmallCart(smallSize);
			
			if( SmallResult > 0 ) {
				System.out.println("Small장바구니 추가 성공"); 
			} else {
				System.out.println("Small장바구니 추가 실패");
			}
		}
		
		// Middle 사이즈 장바구니 추가
		if(mAmount != 0) {
			
			Map<String, String> middleSize = new HashMap<String, String>();
			
			middleSize.put("userId", userId);
			middleSize.put("pCode", pCode);
			middleSize.put("mAmount", String.valueOf(mAmount));
			
			int MiddleResult = cartService.insertMiddleCart(middleSize);
				
			if( MiddleResult > 0 ) {
				System.out.println("Middle장바구니 추가 성공"); 
			} else {
				System.out.println("Middle장바구니 추가 실패");
			}
		}
				
		// Large 사이즈 장바구니 추가
		if(lAmount != 0) {
			
			Map<String, String> largeSize = new HashMap<String, String>();
			
			largeSize.put("userId", userId);
			largeSize.put("pCode", pCode);
			largeSize.put("lAmount", String.valueOf(lAmount));
			
			int LargeResult = cartService.insertLargeCart(largeSize);
				
			if( LargeResult > 0 ) {
				System.out.println("Large장바구니 추가 성공"); 
			} else {
				System.out.println("Large장바구니 추가 실패");
			}
		}
		
		model.addAttribute("pCode", pCode)
			 .addAttribute("sAmount", sAmount)
			 .addAttribute("mAmount", mAmount)
			 .addAttribute("lAmount", lAmount);
		
		
		return "user/myPage/myPageCart";	
	}
	
	@RequestMapping("/store/insertStoreComment.do")
	public String insertStoreComment(@RequestParam String userId, @RequestParam int bNo, @RequestParam String cContents, Model model) {
		
		Map<String, String> comment = new HashMap<String, String>();
		
		comment.put("USERID", userId);
		comment.put("BNO", String.valueOf(bNo));
		comment.put("CCONTENTS", cContents);
		
		int result = storeService.insertStoreComment(comment);
		
		// 5. 처리 결과에 따른 view 처리			
		String loc = "/store/storeDetail.do?no="+bNo;			
		String msg ="";
								
		if( result > 0 ) {				
			msg = "댓글 등록 성공";				
		} else {				
			msg = "댓글 등록 실패!";				
		}
								
		model.addAttribute("loc", loc).addAttribute("msg", msg);
					
		return "common/msg";
	}

	@RequestMapping("/store/deleteStoreComment.do")
	public String deleteComment(@RequestParam int bNo, @RequestParam int bcNo, Model model) {
		
		int result = storeService.deleteStoreComment(bcNo);
		
		// 5. 처리 결과에 따른 view 처리
		String loc = "/store/storeDetail.do?no="+bNo;
		String msg ="";
	
		if( result > 0 ) {
			msg = "댓글 삭제 성공";
		} else {
			msg = "댓글 삭제 실패!";
		}
	
		model.addAttribute("loc", loc).addAttribute("msg", msg);
		
		return "common/msg";
	}
	@RequestMapping("/store/selectOuterSearch.do")
	public String selectOuterSearch(@RequestParam(value="cPage", required=false, defaultValue="1") int cPage,
									   @RequestParam String searchCt, @RequestParam String search, Model model) {

		int numPerPage = 8; // 한 페이지 당 게시글 and 페이지 수
		
		Map<String, String> searchMap = new HashMap<String, String>();
		searchMap.put("searchCt", searchCt);
		searchMap.put("search", search);
		
		// 1. 현재 페이지 게시글 구하기
		List<Map<String, String>> list = storeService.selectOuterSearch(cPage, numPerPage, searchMap);
		
		// 2. 검색된 게시글 수 (페이지 처리를 위함)
		int totalContents = storeService.selectOuterSearchCount(searchMap);
		
		// 3. 페이지 계산된 HTML 구하기
		String pageBar = Utils.getPageBar(totalContents, cPage, numPerPage, "selectOuterSearch.do", searchMap);
		
		String msg = "검색 결과 : " + totalContents + " 건의 게시글이 있습니다.";
		
		model.addAttribute("list", list)
			 .addAttribute("totalContents", totalContents)
			 .addAttribute("numPerPage", numPerPage)
			 .addAttribute("pageBar", pageBar)
			 .addAttribute("msg", msg);
		
		return "user/store/outerStore";
	}
	
	@RequestMapping("/store/selectTopSearch.do")
	public String selectTopSearch(@RequestParam(value="cPage", required=false, defaultValue="1") int cPage,
									   @RequestParam String searchCt, @RequestParam String search, Model model) {

		int numPerPage = 8; // 한 페이지 당 게시글 and 페이지 수
		
		Map<String, String> searchMap = new HashMap<String, String>();
		searchMap.put("searchCt", searchCt);
		searchMap.put("search", search);
		
		// 1. 현재 페이지 게시글 구하기
		List<Map<String, String>> list = storeService.selectTopSearch(cPage, numPerPage, searchMap);
		
		// 2. 검색된 게시글 수 (페이지 처리를 위함)
		int totalContents = storeService.selectTopSearchCount(searchMap);
		
		// 3. 페이지 계산된 HTML 구하기
		String pageBar = Utils.getPageBar(totalContents, cPage, numPerPage, "selectTopSearch.do", searchMap);
		
		String msg = "검색 결과 : " + totalContents + " 건의 게시글이 있습니다.";
		
		model.addAttribute("list", list)
			 .addAttribute("totalContents", totalContents)
			 .addAttribute("numPerPage", numPerPage)
			 .addAttribute("pageBar", pageBar)
			 .addAttribute("msg", msg);
		
		return "user/store/topStore";
	}
	
	@RequestMapping("/store/selectPantsSearch.do")
	public String selectStoreSearch(@RequestParam(value="cPage", required=false, defaultValue="1") int cPage,
									   @RequestParam String searchCt, @RequestParam String search, Model model) {

		int numPerPage = 8; // 한 페이지 당 게시글 and 페이지 수
		
		Map<String, String> searchMap = new HashMap<String, String>();
		searchMap.put("searchCt", searchCt);
		searchMap.put("search", search);
		
		// 1. 현재 페이지 게시글 구하기
		List<Map<String, String>> list = storeService.selectPantsSearch(cPage, numPerPage, searchMap);
		
		// 2. 검색된 게시글 수 (페이지 처리를 위함)
		int totalContents = storeService.selectPantsSearchCount(searchMap);
		
		// 3. 페이지 계산된 HTML 구하기
		String pageBar = Utils.getPageBar(totalContents, cPage, numPerPage, "selectPantsSearch.do", searchMap);
		
		String msg = "검색 결과 : " + totalContents + " 건의 게시글이 있습니다.";
		
		model.addAttribute("list", list)
			 .addAttribute("totalContents", totalContents)
			 .addAttribute("numPerPage", numPerPage)
			 .addAttribute("pageBar", pageBar)
			 .addAttribute("msg", msg);
		
		return "user/store/pantsStore";
	}
}