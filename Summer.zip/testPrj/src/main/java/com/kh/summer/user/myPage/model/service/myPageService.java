package com.kh.summer.user.myPage.model.service;

import java.util.List;
import java.util.Map;

import com.kh.summer.user.memberSize.pants.model.vo.MemberPantsSize;
import com.kh.summer.user.memberSize.top.model.vo.MemberTopSize;

//import com.kh.summer.user.pants.model.vo.Pants;
//import com.kh.summer.user.top.model.vo.Top;

public interface myPageService {
	
	List<Map<String, String>> selectReviewList(int cPage, int numPerPage, String userId);

	int selectReviewTotalContents(String userId);

	List<Map<String, String>> selectLikeList(int cPage, int numPerPage, String userId);

	int selectLikeTotalContents(String userId);

	List<Map<String, String>> selectPointList(int cPage, int numPerPage, String userId);

	int selectPointTotalContents(String userId);

	MemberTopSize selectMemberTopSize(String userId);

	MemberPantsSize selectMemberPantsSize(String userId);

	int insertMemberTopSize(String userId, Map<String, Object> topMap);

	int insertMemberPantsSize(String userId, Map<String, Object> pantsMap);

	int updateMemberTopSize(String userId, Map<String, Object> topMap);

	int updateMemberPantsSize(String userId, Map<String, Object> pantsMap);

	List<Map<String, String>> selectQuestionList(int cPage, int numPerPage, String userId);

	int selectQuestionTotalContents(String userId);

}
