package com.kh.summer.admin.notice.model.service;

import java.util.List;
import java.util.Map;

import com.kh.summer.user.attachment.model.vo.Attachment;
import com.kh.summer.user.board.model.vo.Board;

public interface AdminNoticeService {
	
	int insertNotice(Board board, List<Attachment> attachList);
	
}
