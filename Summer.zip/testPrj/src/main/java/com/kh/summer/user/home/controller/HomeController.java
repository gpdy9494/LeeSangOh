package com.kh.summer.user.home.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.kh.summer.user.store.model.service.StoreService;

@Controller
public class HomeController {
	
	@Autowired
	StoreService storeService;
	
	@RequestMapping("index.do")
	public String selectStoreMain(Model model) {
		List<Map<String, String>> list = storeService.selectStoreMainList();
		
		System.out.println("list : " + list);
		
		model.addAttribute("list", list);
		
		return "index";
	}
	
	
}












