package com.kh.summer.user.store.model.dao;

import java.util.List;
import java.util.Map;

import com.kh.summer.user.attachment.model.vo.Attachment;
//import com.kh.summer.user.attachment.model.vo.Attachment;
import com.kh.summer.user.store.model.vo.Store;

public interface StoreDAO {

	List<Map<String, String>> selectStoreTopList(int cPage, int numPerPage, String sort);

	int selectStoreTopTotalContents();
	
	List<Map<String, String>> selectStorePantsList(int cPage, int numPerPage, String sort);

	int selectStorePantsTotalContents();
	
	List<Map<String, String>> selectStoreOuterList(int cPage, int numPerPage, String sort);

	int selectStoreOuterTotalContents();
	
	int insertStore(Store store);
	
	int insertAttachment(Attachment a);
	
	Map<String, String> selectOneStore(int bNo);
	
	List<Map<String, String>> selectAttachmentList(int bNo);

	int updateViews(int bNo);

	List<Map<String, String>> selectStoreCommentList(int bNo);

	int updateLike(Map<String, String> like);

	List<Map<String, Object>> selectTopSize(int bNo);
	
	List<Map<String, Object>> selectPantsSize(int bNo);

	//int selectSmallSize(Map<String, String> size);

	int insertStoreComment(Map<String, String> comment);

	int deleteStoreComment(int bcNo);

	List<Map<String, String>> selectStoreMainList();

	Map<String, Object> selectMyTopSize(String Id);
	
	Map<String, Object> selectMyPantsSize(String Id);

	List<Object> isLike(Map<String, String> like);
	
	int updateProductSold(String strProductCode);

	List<Map<String, String>> selectStoreOuterBestItems();
	
	List<Map<String, String>> selectStoreTopBestItems();
	
	List<Map<String, String>> selectStorePantsBestItems();

	List<Map<String, String>> selectMainPageList();

	List<Map<String, String>> selectOuterSearch(int cPage, int numPerPage, Map<String, String> searchMap);

	int selectOuterSearchCount(Map<String, String> searchMap);

	List<Map<String, String>> selectTopSearch(int cPage, int numPerPage, Map<String, String> searchMap);

	int selectTopSearchCount(Map<String, String> searchMap);

	List<Map<String, String>> selectPantsSearch(int cPage, int numPerPage, Map<String, String> searchMap);

	int selectPantsSearchCount(Map<String, String> searchMap);
	
	
	


	
}
