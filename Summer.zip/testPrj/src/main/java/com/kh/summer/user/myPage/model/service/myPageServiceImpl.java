package com.kh.summer.user.myPage.model.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kh.summer.user.memberSize.pants.model.vo.MemberPantsSize;
import com.kh.summer.user.memberSize.top.model.vo.MemberTopSize;
import com.kh.summer.user.myPage.model.dao.myPageDAO;
//import com.kh.summer.user.pants.model.vo.Pants;
//import com.kh.summer.user.top.model.vo.Top;

@Service
public class myPageServiceImpl implements myPageService {
	
	@Autowired
	myPageDAO mypageDAO;

	@Override
	public List<Map<String, String>> selectReviewList(int cPage, int numPerPage, String userId) {
		return mypageDAO.selectReviewList(cPage, numPerPage, userId);
	}

	@Override
	public int selectReviewTotalContents(String userId) {
		return mypageDAO.selectReviewTotalContents(userId);
	}

	@Override
	public List<Map<String, String>> selectLikeList(int cPage, int numPerPage, String userId) {
		return mypageDAO.selectLikeList(cPage, numPerPage, userId);
	}

	@Override
	public int selectLikeTotalContents(String userId) {
		return mypageDAO.selectLikeTotalContents(userId);
	}

	@Override
	public List<Map<String, String>> selectPointList(int cPage, int numPerPage, String userId) {
		return mypageDAO.selectPointList(cPage, numPerPage, userId);
	}

	@Override
	public int selectPointTotalContents(String userId) {
		return mypageDAO.selectPointTotalContents(userId);
	}

	@Override
	public MemberTopSize selectMemberTopSize(String userId) {
		return mypageDAO.selectMemberTopSize(userId);
	}
	
	@Override
	public MemberPantsSize selectMemberPantsSize(String userId) {
		return mypageDAO.selectMemberPantsSize(userId);
	}
	
	@Override
	public int insertMemberTopSize(String userId, Map<String, Object> topMap) {
		
		return mypageDAO.insertMemberTopSize(topMap);
	}
	
	@Override
	public int insertMemberPantsSize(String userId, Map<String, Object> pantsMap) {
		
		return mypageDAO.insertMemberPantsSize(pantsMap);
	}
	
	@Override
	public int updateMemberTopSize(String userId, Map<String, Object> topMap) {
		
		return mypageDAO.updateMemberTopSize(topMap);
		
	}

	@Override
	public int updateMemberPantsSize(String userId, Map<String, Object> pantsMap) {
		
		return mypageDAO.updateMemberPantsSize(pantsMap);
		
	}
	
	@Override
	public List<Map<String, String>> selectQuestionList(int cPage, int numPerPage, String userId) {
		return mypageDAO.selectQuestionList(cPage, numPerPage, userId);
	}

	@Override
	public int selectQuestionTotalContents(String userId) {
		return mypageDAO.selectQuestionTotalContents(userId);
	}

}
