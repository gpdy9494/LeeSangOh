package com.kh.summer.admin.notice.model.dao;

import java.util.List;
import java.util.Map;

import com.kh.summer.user.attachment.model.vo.Attachment;
import com.kh.summer.user.board.model.vo.Board;

public interface AdminNoticeDAO {

	int insertNotice(Board board);
	
	int insertAttachment(Attachment a);

}
