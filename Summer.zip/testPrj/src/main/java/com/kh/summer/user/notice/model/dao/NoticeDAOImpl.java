package com.kh.summer.user.notice.model.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.RowBounds;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.kh.summer.user.board.model.vo.Board;

@Repository
public class NoticeDAOImpl implements NoticeDAO {

	@Autowired
	SqlSessionTemplate sqlSession;
	
	@Override
	public List<Map<String, String>> selectNoticeList(int cPage, int numPerPage) {
		RowBounds rows = new RowBounds((cPage-1)*numPerPage, numPerPage);
		
		return sqlSession.selectList("noticeMapper.selectNoticeList", null, rows);
	}

	@Override
	public int selectNoticeTotalContents() {
		return sqlSession.selectOne("noticeMapper.selectNoticeTotalContents");
	}

	@Override
	public Map<String, String> selectOneNotice(int bNo) {
		return sqlSession.selectOne("noticeMapper.selectOneNotice", bNo);
	}

	@Override
	public List<Map<String, String>> selectAttachmentList(int no) {
		return sqlSession.selectList("noticeMapper.selectAttachmentList", no);
	}

	@Override
	public List<Map<String, String>> selectNoticeCommentList(int no) {
		return sqlSession.selectList("noticeMapper.selectNoticeCommentList", no);
	}

	@Override
	public int updateViews(int bNo) {
		return sqlSession.update("noticeMapper.updateViews", bNo);
	}

	@Override
	public int insertComment(Map<String, String> comment) {
		return sqlSession.insert("noticeMapper.insertComment", comment);
	}

	@Override
	public int deleteComment(int bcNo) {
		return sqlSession.update("noticeMapper.deleteComment", bcNo);
	}

}
