package com.kh.summer.user.myPage.model.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.RowBounds;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.kh.summer.user.memberSize.pants.model.vo.MemberPantsSize;
import com.kh.summer.user.memberSize.top.model.vo.MemberTopSize;

//import com.kh.summer.user.pants.model.vo.Pants;
//import com.kh.summer.user.top.model.vo.Top;

@Repository
public class myPageDAOImpl implements myPageDAO {
	
	@Autowired
	SqlSessionTemplate sqlSession;

	@Override
	public List<Map<String, String>> selectReviewList(int cPage, int numPerPage, String userId) {
		RowBounds rows = new RowBounds((cPage-1)*numPerPage, numPerPage);
		return sqlSession.selectList("mypageMapper.selectReviewList", userId, rows);
	}

	@Override
	public int selectReviewTotalContents(String userId) {
		return sqlSession.selectOne("mypageMapper.selectReviewTotalContents", userId);
	}

	@Override
	public List<Map<String, String>> selectLikeList(int cPage, int numPerPage, String userId) {
		RowBounds rows = new RowBounds((cPage-1)*numPerPage, numPerPage);
		return sqlSession.selectList("mypageMapper.selectLikeList", userId, rows);
	}

	@Override
	public int selectLikeTotalContents(String userId) {
		return sqlSession.selectOne("mypageMapper.selectLikeTotalContents", userId);
	}

	@Override
	public List<Map<String, String>> selectPointList(int cPage, int numPerPage, String userId) {
		RowBounds rows = new RowBounds((cPage-1)*numPerPage, numPerPage);
		return sqlSession.selectList("mypageMapper.selectPointList", userId, rows);
	}

	@Override
	public int selectPointTotalContents(String userId) {
		return sqlSession.selectOne("mypageMapper.selectPointTotalContents", userId);
	}
	
	@Override
	public MemberTopSize selectMemberTopSize(String userId) {
		return sqlSession.selectOne("mypageMapper.selectMemberTopSize", userId);
	}
	

	@Override
	public MemberPantsSize selectMemberPantsSize(String userId) {
		return sqlSession.selectOne("mypageMapper.selectMemberPantsSize", userId);
	}

	@Override
	public int insertMemberTopSize(Map<String, Object> topMap) {
		return sqlSession.insert("mypageMapper.insertMemberTopSize", topMap);
	}

	@Override
	public int insertMemberPantsSize(Map<String, Object> pantsMap) {
		return sqlSession.insert("mypageMapper.insertMemberPantsSize", pantsMap);
	}

	@Override
	public int updateMemberTopSize(Map<String, Object> topMap) {
		return sqlSession.update("mypageMapper.updateMemberTopSize", topMap);
	}

	@Override
	public int updateMemberPantsSize(Map<String, Object> pantsMap) {
		return sqlSession.update("mypageMapper.updateMemberPantsSize", pantsMap);
	}

	@Override
	public List<Map<String, String>> selectQuestionList(int cPage, int numPerPage, String userId) {
		RowBounds rows = new RowBounds((cPage-1)*numPerPage, numPerPage);
		return sqlSession.selectList("mypageMapper.selectQuestionList", userId, rows);
	}

	@Override
	public int selectQuestionTotalContents(String userId) {
		return sqlSession.selectOne("mypageMapper.selectQuestionTotalContents", userId);
	}

}
