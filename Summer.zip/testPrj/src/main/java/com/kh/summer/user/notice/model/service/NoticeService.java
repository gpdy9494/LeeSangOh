package com.kh.summer.user.notice.model.service;

import java.util.List;
import java.util.Map;

import com.kh.summer.user.attachment.model.vo.Attachment;
import com.kh.summer.user.board.model.vo.Board;

public interface NoticeService {

	List<Map<String, String>> selectNoticeList(int cPage, int numPerPage);
	
	int selectNoticeTotalContents();
	
	Map<String, String> selectOneNotice(int bNo);

	List<Map<String, String>> selectAttachmentList(int no);

	List<Map<String, String>> selectBoardCommentList(int no);

	int insertComment(Map<String, String> comment);

	int deleteComment(int bcNo);

}
