package com.kh.summer.user.store.model.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kh.summer.user.attachment.model.vo.Attachment;
import com.kh.summer.user.store.model.dao.StoreDAO;
import com.kh.summer.user.store.model.vo.Store;

@Service
public class storeServiceImpl implements StoreService {

	@Autowired
	StoreDAO storeDAO;
	
	@Override
	public List<Map<String, String>> selectStoreTopList(int cPage, int numPerPage, String sort) {
		
		return storeDAO.selectStoreTopList(cPage, numPerPage, sort);
	}

	@Override
	public int selectStoreTopTotalContents() {
		return storeDAO.selectStoreTopTotalContents();
	}
	
	@Override
	public List<Map<String, String>> selectStorePantsList(int cPage, int numPerPage, String sort) {
		
		return storeDAO.selectStorePantsList(cPage, numPerPage, sort);
	}

	@Override
	public int selectStorePantsTotalContents() {
		return storeDAO.selectStorePantsTotalContents();
	}
	
	@Override
	public List<Map<String, String>> selectStoreOuterList(int cPage, int numPerPage, String sort) {
		
		return storeDAO.selectStoreOuterList(cPage, numPerPage, sort);
	}

	@Override
	public int selectStoreOuterTotalContents() {
		return storeDAO.selectStoreOuterTotalContents();
	}

	@Override
	public int insertStore(Store store, List<Attachment> attachList) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override 
	public Map<String, String> selectOneStore(int bNo) {		
		Map<String, String> store = storeDAO.selectOneStore(bNo);
		// 조회수 1 증가!
		if( store != null ) storeDAO.updateViews(bNo);
		
		return store;
	}
	
	@Override
	public int updateLike(Map<String, String> like){
		return storeDAO.updateLike(like);
	}

	@Override 
	public List<Map<String, String>> selectAttachmentList(int bNo) {
		return storeDAO.selectAttachmentList(bNo);
	}

	@Override
	public List<Map<String, String>> selectStoreCommentList(int bNo) {
		return storeDAO.selectStoreCommentList(bNo);
	}

	@Override
	public List<Map<String, Object>> selectTopSize(int bNo) {
		return storeDAO.selectTopSize(bNo);
	}
	
	@Override
	public List<Map<String, Object>> selectPantsSize(int bNo) {
		return storeDAO.selectPantsSize(bNo);
	}

	/*
	@Override
	public int selectSmallSize(Map<String, String> size) {
		return storeDAO.selectSmallSize(size);
	}
*/
	
	@Override
	public int insertStoreComment(Map<String, String> comment) {
		return storeDAO.insertStoreComment(comment);
	}

	
	@Override
	public int deleteStoreComment(int bcNo) {
		return storeDAO.deleteStoreComment(bcNo);
	}

	@Override
	public List<Map<String, String>> selectStoreMainList() {
		return storeDAO.selectStoreMainList();
	}

	@Override
	public Map<String, Object> selectMyTopSize(String Id) {
		return storeDAO.selectMyTopSize(Id);
	}
	
	@Override
	public Map<String, Object> selectMyPantsSize(String Id) {
		return storeDAO.selectMyPantsSize(Id);
	}

	@Override
	public List<Object> isLike(Map<String, String> like) {
		return storeDAO.isLike(like);
	}

	
	@Override
	public int updateProductSold(String strProductCode) { 
		return storeDAO.updateProductSold(strProductCode); 
	}

	@Override
	public List<Map<String, String>> selectStoreOuterBestItems() {
		return storeDAO.selectStoreOuterBestItems();
	}
	
	@Override
	public List<Map<String, String>> selectStoreTopBestItems() {
		return storeDAO.selectStoreTopBestItems();
	}
	
	@Override
	public List<Map<String, String>> selectStorePantsBestItems() {
		return storeDAO.selectStorePantsBestItems();
	}

	@Override
	public List<Map<String, String>> selectMainPageList() {
		return storeDAO.selectMainPageList();
	}

	@Override
	public List<Map<String, String>> selectOuterSearch(int cPage, int numPerPage, Map<String, String> searchMap) {
		return storeDAO.selectOuterSearch(cPage, numPerPage, searchMap);
	}

	@Override
	public int selectOuterSearchCount(Map<String, String> searchMap) {
		return storeDAO.selectOuterSearchCount(searchMap);
	}

	@Override
	public List<Map<String, String>> selectTopSearch(int cPage, int numPerPage, Map<String, String> searchMap) {
		return storeDAO.selectTopSearch(cPage, numPerPage, searchMap);
	}

	@Override
	public int selectTopSearchCount(Map<String, String> searchMap) {
		return storeDAO.selectTopSearchCount(searchMap);
	}

	@Override
	public List<Map<String, String>> selectPantsSearch(int cPage, int numPerPage, Map<String, String> searchMap) {
		return storeDAO.selectPantsSearch(cPage, numPerPage, searchMap);
	}

	@Override
	public int selectPantsSearchCount(Map<String, String> searchMap) {
		return storeDAO.selectPantsSearchCount(searchMap);
	}

	
}
