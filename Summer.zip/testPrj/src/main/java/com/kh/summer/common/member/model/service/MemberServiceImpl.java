package com.kh.summer.common.member.model.service;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kh.summer.common.member.model.dao.MemberDAO;
import com.kh.summer.common.member.model.vo.Member;

@Service
public class MemberServiceImpl implements MemberService {

	@Autowired
	private MemberDAO memberDAO;
	
	@Override
	public int insertMember(Member member) {
		
		return memberDAO.insertMember(member);
	}

	@Override
	public Member selectOneMember(String userId) {
		return memberDAO.selectOneMember(userId);
	}

	@Override
	public int updateMember(Member member) {
		return memberDAO.updateMember(member);
	}

	@Override
	public int checkIdDuplicate(String userId) {
		HashMap<String, Object> hmap = new HashMap<String, Object>();
		hmap.put("userId", userId);
		
		return memberDAO.checkIdDuplicate(hmap);
	}

	@Override
	public int deleteMember(String userId) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int nickNameDupChk(String nickName) {
		HashMap<String, Object> hmap = new HashMap<String, Object>();
		hmap.put("nickName", nickName);
		System.out.println(hmap);
		return memberDAO.nickNameDupChk(hmap);
	}

	@Override
	public int emailDupChk(String email) {
		HashMap<String, Object> hmap = new HashMap<String, Object>();
		hmap.put("email", email);
		System.out.println(hmap);
		return memberDAO.emailDupChk(hmap);
	}

	@Override
	public Member findID(Member member) {
		return memberDAO.findID(member);
	}

	@Override
	public int findInfoCheck(Member member) {
		return memberDAO.findInfoCheck(member);
	}

	@Override
	public int changePW(Member member) {
		// TODO Auto-generated method stub
		return 0;
	}

	

}
