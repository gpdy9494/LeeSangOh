package com.kh.summer.user.memberSize.top.model.vo;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class MemberTopSize {
	private String userId;
	private int total;
	private int shoulder;
	private int chest;
	private int sleeve;
	private int height;
	private int weight;
}
