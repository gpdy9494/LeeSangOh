package com.kh.summer.common.member.model.dao;

import java.util.HashMap;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.kh.summer.common.member.model.vo.Member;


@Repository
public class MemberDAOImpl implements MemberDAO {

	@Autowired
	private SqlSessionTemplate sqlSession;
	
	@Override
	public int insertMember(Member member) {

		return sqlSession.insert("memberMapper.insertMember", member);
	}

	@Override
	public Member selectOneMember(String userId) {
		return sqlSession.selectOne("memberMapper.selectMember", userId);
	}

	@Override
	public int updateMember(Member member) {

		return sqlSession.update("memberMapper.updateMember", member);
	}

	@Override
	public int deleteMember(String userId) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int checkIdDuplicate(HashMap<String, Object> hmap) {
		
		return sqlSession.selectOne("memberMapper.checkIdDuplicate", hmap);
	}

	@Override
	public int nickNameDupChk(HashMap<String, Object> hmap) {
		
		return sqlSession.selectOne("memberMapper.nickNameDupChk", hmap);
	}

	@Override
	public int emailDupChk(HashMap<String, Object> hmap) {
		int result = sqlSession.selectOne("memberMapper.emailDupChk");
		System.out.printf("result : " + result);
		return result;
		//return sqlSession.selectOne("memberMapper.nickNameDupChk", hmap);
	}

	@Override
	public Member findID(Member member) {
		return sqlSession.selectOne("memberMapper.findID", member);
	}

	@Override
	public int findInfoCheck(Member member) {
		return sqlSession.selectOne("memberMapper.findInfoCheck", member);
	}

	@Override
	public int changePW(Member member) {
		// TODO Auto-generated method stub
		return 0;
	}

	

}
