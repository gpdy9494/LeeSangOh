package com.kh.summer.user.orderinfo.model.vo;

import java.sql.Date;
import java.util.List;

import org.springframework.stereotype.Component;

import com.kh.summer.user.attachment.model.vo.Attachment;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Data
@Component
public class OrderInfo {

	private int oNo;
	private String rName;
	private String rAddress;
	private String rPhone;
	private String requirement;
	private String userId;
	private int totalPrice;
	private Date orderDate;
	private String payInfo;
	private String orderInfo;
	private int osNo;
	private String deliveryNo;
	private Date endDate;
	public String pCode;
	
}
