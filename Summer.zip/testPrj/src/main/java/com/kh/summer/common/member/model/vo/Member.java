package com.kh.summer.common.member.model.vo;

import java.io.Serializable;
import java.sql.Date;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Member implements Serializable {

	private static final long serialVersionUID = 1004L;
	
	private String userId;
	private String password;
	private String userName;
	private String nickName;
	private String birth;
	private String gender;
	private String phone;
	private String address;
	private String email;
	private Date enrollDate;
	private String mstatus;
	private Date deleteDate;
	private int point;
	private String mtype;

	
	public Member(String userId, String password) {
		super();
		this.userId = userId;
		this.password = password;
	}
	
	public Member(String userId, String password, String nickName, String email, String phone, String address) {
		super();
		this.userId = userId;
		this.password = password;
		this.nickName = nickName;
		this.email = email;
		this.phone = phone;
		this.address = address;
	}


	public Member(String userId, String password, String userName, String nickName, String birth, String gender,
			String phone, String address, String email) {
		super();
		this.userId = userId;
		this.password = password;
		this.userName = userName;
		this.nickName = nickName;
		this.birth = birth;
		this.gender = gender;
		this.phone = phone;
		this.address = address;
		this.email = email;
	}
}